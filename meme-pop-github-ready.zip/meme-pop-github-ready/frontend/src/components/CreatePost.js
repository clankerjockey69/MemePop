import React, { useState } from 'react';
import axios from 'axios';

export default function CreatePost({ onCreate }){
  const [content, setContent] = useState('');
  const [creating, setCreating] = useState(false);

  const author = localStorage.getItem('mp_author') || `anon${Math.floor(Math.random()*10000)}`;

  if (!localStorage.getItem('mp_author')) localStorage.setItem('mp_author', author);

  const handleCreate = async () => {
    if (!content.trim()) return alert('Write something!');
    setCreating(true);
    try {
      const urlParams = new URLSearchParams(window.location.search);
      const ref = urlParams.get('r');

      const res = await axios.post(`${process.env.REACT_APP_API_URL || 'http://localhost:4000'}/api/posts`, {
        author, type: 'text', content, refcode: ref
      });
      const id = res.data.post.id;
      const shareUrl = `${window.location.origin}/?post=${id}`;
      try { await navigator.clipboard.writeText(shareUrl); } catch(e){}
      alert(`Post created! Share link copied:\n${shareUrl}`);
      setContent('');
      onCreate && onCreate();
    } catch (err) {
      console.error(err);
      alert('Error creating post');
    } finally { setCreating(false); }
  };

  return (
    <div style={{ marginBottom: 20 }}>
      <textarea
        rows={3}
        placeholder="Write a short post or meme caption..."
        value={content}
        onChange={e=>setContent(e.target.value)}
        style={{ width: '100%', padding: 10 }}
      />
      <div style={{ marginTop: 8 }}>
        <button onClick={handleCreate} disabled={creating}>
          {creating ? 'Creating...' : 'Create & Share'}
        </button>
      </div>
    </div>
  );
}
