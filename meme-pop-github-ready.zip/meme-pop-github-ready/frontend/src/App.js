import React, { useEffect, useState } from 'react';
import Home from './components/Home';
import CreatePost from './components/CreatePost';
import { io } from 'socket.io-client';

const socket = io(process.env.REACT_APP_API_URL || 'http://localhost:4000');

export default function App(){
  const [refreshKey, setRefreshKey] = useState(0);

  useEffect(() => {
    socket.on('new_post', data => {
      setRefreshKey(k => k + 1);
    });
    socket.on('update_post', data => {
      setRefreshKey(k => k + 1);
    });
    return () => {
      socket.off('new_post');
      socket.off('update_post');
    };
  }, []);

  return (
    <div style={{ maxWidth: 800, margin: '0 auto', padding: 20 }}>
      <h1>MemePop (prototype)</h1>
      <CreatePost onCreate={() => setRefreshKey(k => k + 1)} />
      <Home key={refreshKey} />
    </div>
  );
}
