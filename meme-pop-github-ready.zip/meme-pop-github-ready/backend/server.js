const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const Database = require('better-sqlite3');
const { nanoid } = require('nanoid');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' } });

app.use(cors());
app.use(bodyParser.json());

// DB init
const db = new Database(path.join(__dirname, 'db.sqlite'));
db.prepare(`
  CREATE TABLE IF NOT EXISTS posts (
    id TEXT PRIMARY KEY,
    author TEXT,
    type TEXT,
    content TEXT,
    created INTEGER,
    views INTEGER DEFAULT 0,
    votes INTEGER DEFAULT 0,
    refcode TEXT
  )
`).run();

// helper statements
const insertPost = db.prepare(`INSERT INTO posts (id, author, type, content, created, refcode) VALUES (?, ?, ?, ?, ?, ?)`);
const getPost = db.prepare(`SELECT * FROM posts WHERE id = ?`);
const incViews = db.prepare(`UPDATE posts SET views = views + 1 WHERE id = ?`);
const incVotes = db.prepare(`UPDATE posts SET votes = votes + 1 WHERE id = ?`);

// trending: compute on the fly
function computeScore(post) {
  const ageHours = Math.max((Date.now() - post.created) / (1000*60*60), 0.001);
  return post.votes * 10 + post.views * 1 - ageHours * 2;
}

// API: create post
app.post('/api/posts', (req, res) => {
  const { author = 'anon', type = 'text', content = '', refcode = null } = req.body;
  if (!content || content.length > 2000) return res.status(400).json({ error: 'Invalid content' });

  const id = nanoid(8);
  const created = Date.now();
  insertPost.run(id, author.slice(0,50), type, content, created, refcode || null);
  const post = getPost.get(id);

  // broadcast new post to realtime feed
  io.emit('new_post', { ...post, score: computeScore(post) });
  res.json({ post });
});

// API: get post (and increment views)
app.get('/api/posts/:id', (req, res) => {
  const id = req.params.id;
  const post = getPost.get(id);
  if (!post) return res.status(404).json({ error: 'Not found' });
  incViews.run(id);
  const updated = getPost.get(id);
  io.emit('update_post', { id: updated.id, views: updated.views, votes: updated.votes, score: computeScore(updated) });
  res.json({ post: updated });
});

// API: upvote
app.post('/api/posts/:id/vote', (req, res) => {
  const id = req.params.id;
  const post = getPost.get(id);
  if (!post) return res.status(404).json({ error: 'Not found' });
  incVotes.run(id);
  const updated = getPost.get(id);
  io.emit('update_post', { id: updated.id, views: updated.views, votes: updated.votes, score: computeScore(updated) });
  res.json({ post: updated });
});

// API: feed (latest + trending)
app.get('/api/feed', (req, res) => {
  const rows = db.prepare('SELECT * FROM posts ORDER BY created DESC LIMIT 200').all();
  const withScore = rows.map(r => ({ ...r, score: computeScore(r) }));
  withScore.sort((a,b) => b.score - a.score);
  res.json({ feed: withScore.slice(0,50) });
});

// Serve frontend in production (optional)
app.use(express.static(path.join(__dirname, '..', 'frontend', 'build')));
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'build', 'index.html'));
});

// Simple metrics endpoint for referral tracking
app.post('/api/track-ref', (req, res) => {
  res.json({ ok: true });
});

const PORT = process.env.PORT || 4000;
server.listen(PORT, () => console.log(`Server listening on ${PORT}`));
