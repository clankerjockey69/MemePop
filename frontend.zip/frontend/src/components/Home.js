import React, { useEffect, useState } from 'react';
import axios from 'axios';
import PostCard from './PostCard';

export default function Home(){
  const [feed, setFeed] = useState([]);
  const API = process.env.REACT_APP_API_URL || 'http://localhost:4000';

  const fetchFeed = async () => {
    const res = await axios.get(`${API}/api/feed`);
    setFeed(res.data.feed || []);
  };

  useEffect(() => { fetchFeed(); }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const postId = params.get('post');
    const ref = params.get('r');
    if (postId) {
      axios.get(`${API}/api/posts/${postId}`).then(r => {
        fetchFeed();
      }).catch(()=>{});
      if (ref) {
        axios.post(`${API}/api/track-ref`, { ref, postId }).catch(()=>{});
      }
    }
  }, []);

  return (
    <div>
      <h2>Trending</h2>
      {feed.length === 0 && <div>Loading...</div>}
      {feed.map(p => <PostCard key={p.id} post={p} onAction={fetchFeed} />)}
    </div>
  );
}
