import React from 'react';
import axios from 'axios';

export default function PostCard({ post, onAction }){
  const API = process.env.REACT_APP_API_URL || 'http://localhost:4000';

  const handleVote = async () => {
    try {
      await axios.post(`${API}/api/posts/${post.id}/vote`);
      onAction && onAction();
    } catch (e) { console.error(e); }
  };

  const handleShare = () => {
    const shareUrl = `${window.location.origin}/?post=${post.id}`;
    try { navigator.clipboard.writeText(shareUrl); alert('Link copied!'); } catch(e){}
  };

  return (
    <div style={{ border: '1px solid #ddd', padding: 12, marginBottom: 10, borderRadius: 6 }}>
      <div style={{ fontSize: 12, color: '#666' }}>{post.author} • {new Date(post.created).toLocaleString()}</div>
      <div style={{ marginTop: 8, marginBottom: 8 }}>{post.content}</div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
        <button onClick={handleVote}>🔥 {post.votes}</button>
        <button onClick={handleShare}>Share</button>
        <div style={{ marginLeft: 'auto', fontSize: 12, color: '#999' }}>
          Views: {post.views} • Score: {Math.round(post.score || 0)}
        </div>
      </div>
    </div>
  );
}
